class Fomenu:
    def __init__(self):
        print("""\n\n
---------------------------------------------------------------
Kérlek válassz az alábbi opciók közül!\n
\t'a' - Fájlbetöltés
\t'b' - Fájl adatainak kiírása
\t'c' - Új festmények feltöltése
\t'd' - Keresés festmények címe alapján
\t'e' - Keresés stílusok alapján
\t'f' - Festmények statisztikus adatainak a megtekintése
\n'exit' - Kilépés
---------------------------------------------------------------""")
