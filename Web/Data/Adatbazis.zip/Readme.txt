Ide jöhetnek a Főprogram, Modulok és a Adat txt állományok.
